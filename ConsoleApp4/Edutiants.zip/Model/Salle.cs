﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4.Model {
    public class Salle {
        public string Numero { get; set; }

        public string Batiment { get; set; }
    }
}
