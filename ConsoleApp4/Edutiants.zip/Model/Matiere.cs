﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4.Model {
    public class Matiere {

        public string Code { get; set; }
        public string Nom { get; set; }


        public Salle Salle { get; set; }
    }
}
