﻿using ConsoleApp4.Model;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace ConsoleApp4.Services {
    public class SalleService {

        private DemandeALutilisateur _DemandeALutilisateur;
        private List<Salle> _mesSalles = new List<Salle>();

        public SalleService(DemandeALutilisateur demandeALutilisateur) {
            this._DemandeALutilisateur = demandeALutilisateur;
        }


        public Salle CreateSalle() {
            
            Salle s ;
            s = new Salle();
            s.Numero = _DemandeALutilisateur.DemandeString("Numéro de la salle?");
            s.Batiment = _DemandeALutilisateur.DemandeString("Batiment");
            _mesSalles.Add(s);
            return s;
        }

        public Salle DemandeSalle() {

            Salle result=null;
            while (result == null) {
                string saisieUtilisateur = _DemandeALutilisateur.DemandeString("Numéro de la salle ?");
                foreach(Salle s in this._mesSalles) {
                    if (s.Numero == saisieUtilisateur) {
                        result= s;
                    }
                }
            }

            return result;
        }


    }
}
