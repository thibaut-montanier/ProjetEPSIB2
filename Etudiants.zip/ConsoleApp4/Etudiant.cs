﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4 {
    public class Etudiant {

        public string Prenom;
        public int Age;

        public int NbEnfants;

        public List<Matiere> Matieres { get ;set;}
    }
}
