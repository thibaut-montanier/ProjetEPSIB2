﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4 {
    public class Matiere {

        public string Code { get; set; }
        public string Nom { get; set; }
    }
}
